import {
  createContext,
  useContext,
  useState,
  useCallback,
  useEffect,
  type ReactNode,
} from 'react';
import type { User } from '../types';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  clearError: () => void;
  usersList: User[];
  addUser: (newUser: Omit<User, 'id'>, password: string) => boolean;
  deleteUser: (id: string) => boolean;
  changePassword: (id: string, newPassword: string) => boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

// Registered users stored in localStorage
const USERS_KEY = 'sss_registered_users';
const SESSION_KEY = 'sss_session';

interface StoredUser {
  id: string;
  username: string;
  password: string; // hashed
  name: string;
  role: 'admin' | 'operator' | 'viewer';
}

// Simple hash for demo (in production use bcrypt on a server)
function simpleHash(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const chr = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + chr;
    hash |= 0;
  }
  return 'h_' + Math.abs(hash).toString(36) + '_' + str.length;
}

function getStoredUsers(): StoredUser[] {
  try {
    const raw = localStorage.getItem(USERS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}

  // Seed default admin user on first load
  const defaults: StoredUser[] = [
    {
      id: 'usr_admin',
      username: 'admin',
      password: simpleHash('admin123'),
      name: 'Administrator',
      role: 'admin',
    },
    {
      id: 'usr_operator',
      username: 'operator',
      password: simpleHash('operator123'),
      name: 'Security Operator',
      role: 'operator',
    },
    {
      id: 'usr_viewer',
      username: 'viewer',
      password: simpleHash('viewer123'),
      name: 'Viewer',
      role: 'viewer',
    },
  ];
  localStorage.setItem(USERS_KEY, JSON.stringify(defaults));
  return defaults;
}

function getSession(): User | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return null;
}

function setSession(user: User | null) {
  if (user) {
    localStorage.setItem(SESSION_KEY, JSON.stringify(user));
  } else {
    localStorage.removeItem(SESSION_KEY);
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [usersList, setUsersList] = useState<User[]>([]);

  // Restore session and users on mount
  useEffect(() => {
    const saved = getSession();
    if (saved) {
      setUser(saved);
    }
    const stored = getStoredUsers().map(u => ({
      id: u.id,
      username: u.username,
      name: u.name,
      role: u.role,
    }));
    setUsersList(stored);
    setIsLoading(false);
  }, []);

  const login = useCallback(async (username: string, password: string): Promise<boolean> => {
    setError(null);

    // Simulate network delay
    await new Promise(r => setTimeout(r, 800));

    const trimmedUser = username.trim().toLowerCase();
    const trimmedPass = password.trim();

    if (!trimmedUser || !trimmedPass) {
      setError('Please enter both username and password.');
      return false;
    }

    const users = getStoredUsers();
    const found = users.find(u => u.username.toLowerCase() === trimmedUser);

    if (!found) {
      setError('User not found. Check your username.');
      return false;
    }

    if (found.password !== simpleHash(trimmedPass)) {
      setError('Invalid password. Please try again.');
      return false;
    }

    const loggedInUser: User = {
      id: found.id,
      username: found.username,
      name: found.name,
      role: found.role,
    };

    setUser(loggedInUser);
    setSession(loggedInUser);
    return true;
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setSession(null);
  }, []);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  const addUser = useCallback((newUser: Omit<User, 'id'>, password: string) => {
    if (user?.role !== 'admin') {
      setError('Access denied. Only administrators can add users.');
      return false;
    }
    const users = getStoredUsers();
    if (users.find(u => u.username.toLowerCase() === newUser.username.toLowerCase())) {
      setError('Username already exists.');
      return false;
    }
    const newStoredUser: StoredUser = {
      ...newUser,
      id: crypto.randomUUID(),
      password: simpleHash(password),
    };
    users.push(newStoredUser);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    setUsersList(users.map(u => ({ id: u.id, username: u.username, name: u.name, role: u.role })));
    return true;
  }, [user]);

  const deleteUser = useCallback((id: string) => {
    if (user?.role !== 'admin') {
      setError('Access denied. Only administrators can delete users.');
      return false;
    }
    let users = getStoredUsers();
    if (users.find(u => u.id === id)?.role === 'admin' && users.filter(u => u.role === 'admin').length <= 1) {
      setError('Cannot delete the last admin user.');
      return false;
    }
    users = users.filter(u => u.id !== id);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    setUsersList(users.map(u => ({ id: u.id, username: u.username, name: u.name, role: u.role })));
    return true;
  }, [user]);

  const changePassword = useCallback((id: string, newPassword: string) => {
    const users = getStoredUsers();
    const userIndex = users.findIndex(u => u.id === id);
    if (userIndex === -1) return false;
    
    users[userIndex].password = simpleHash(newPassword);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    return true;
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        error,
        login,
        logout,
        clearError,
        usersList,
        addUser,
        deleteUser,
        changePassword,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
