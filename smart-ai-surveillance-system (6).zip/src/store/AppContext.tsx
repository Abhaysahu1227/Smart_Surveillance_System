import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { Alert, AuthorizedFace, GalleryItem, Settings } from '../types';

interface AppContextType {
  alerts: Alert[];
  gallery: GalleryItem[];
  authorizedFaces: AuthorizedFace[];
  settings: Settings;
  isMonitoring: boolean;
  detectedMotion: boolean;
  currentFrame: string | null;
  backendMode: 'browser' | 'python';
  pythonServerUrl: string;
  addAlert: (alert: Omit<Alert, 'id'>) => void;
  addGalleryItem: (item: Omit<GalleryItem, 'id'>) => void;
  addAuthorizedFace: (face: Omit<AuthorizedFace, 'id'>) => string;
  updateAuthorizedFace: (id: string, updates: Partial<AuthorizedFace>) => void;
  removeAuthorizedFace: (id: string) => void;
  updateSettings: (settings: Partial<Settings>) => void;
  toggleMonitoring: () => void;
  setDetectedMotion: (val: boolean) => void;
  setCurrentFrame: (frame: string | null) => void;
  clearAlerts: () => void;
  setBackendMode: (mode: 'browser' | 'python') => void;
  setPythonServerUrl: (url: string) => void;
}

const defaultSettings: Settings = {
  mobileNumbers: [],
  alertEnabled: true,
  motionSensitivity: 30,
  detectionInterval: 1000,
};

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [authorizedFaces, setAuthorizedFaces] = useState<AuthorizedFace[]>([]);
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [detectedMotion, setDetectedMotion] = useState(false);
  const [currentFrame, setCurrentFrame] = useState<string | null>(null);
  
  // Python Backend Integration states
  const [backendMode, setBackendMode] = useState<'browser' | 'python'>('browser');
  const [pythonServerUrl, setPythonServerUrl] = useState('http://localhost:5000');

  const addAlert = useCallback((alert: Omit<Alert, 'id'>) => {
    const newAlert: Alert = {
      ...alert,
      id: crypto.randomUUID(),
    };
    setAlerts(prev => [newAlert, ...prev].slice(0, 100));
    
    if (alert.type === 'unauthorized' && alert.image) {
      const galleryItem: GalleryItem = {
        id: crypto.randomUUID(),
        image: alert.image,
        timestamp: alert.timestamp,
        type: 'unauthorized',
        label: 'Unauthorized Person',
      };
      setGallery(prev => [galleryItem, ...prev].slice(0, 200));
    }
  }, []);

  const addGalleryItem = useCallback((item: Omit<GalleryItem, 'id'>) => {
    const newItem: GalleryItem = {
      ...item,
      id: crypto.randomUUID(),
    };
    setGallery(prev => [newItem, ...prev].slice(0, 200));
  }, []);

  const addAuthorizedFace = useCallback((face: Omit<AuthorizedFace, 'id'>) => {
    const newFace: AuthorizedFace = {
      ...face,
      id: crypto.randomUUID(),
    };
    setAuthorizedFaces(prev => [...prev, newFace]);
    return newFace.id;
  }, []);

  const updateAuthorizedFace = useCallback((id: string, updates: Partial<AuthorizedFace>) => {
    setAuthorizedFaces(prev => prev.map(f => (f.id === id ? { ...f, ...updates } : f)));
  }, []);

  const removeAuthorizedFace = useCallback((id: string) => {
    setAuthorizedFaces(prev => prev.filter(f => f.id !== id));
  }, []);

  const updateSettings = useCallback((updates: Partial<Settings>) => {
    setSettings(prev => ({ ...prev, ...updates }));
  }, []);

  const toggleMonitoring = useCallback(() => {
    setIsMonitoring(prev => !prev);
  }, []);

  const clearAlerts = useCallback(() => {
    setAlerts([]);
  }, []);

  return (
    <AppContext.Provider
      value={{
        alerts,
        gallery,
        authorizedFaces,
        settings,
        isMonitoring,
        detectedMotion,
        currentFrame,
        backendMode,
        pythonServerUrl,
        addAlert,
        addGalleryItem,
        addAuthorizedFace,
        updateAuthorizedFace,
        removeAuthorizedFace,
        updateSettings,
        toggleMonitoring,
        setDetectedMotion,
        setCurrentFrame,
        clearAlerts,
        setBackendMode,
        setPythonServerUrl,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
