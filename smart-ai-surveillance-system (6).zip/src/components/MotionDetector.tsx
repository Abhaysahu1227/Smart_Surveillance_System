import { useRef, useEffect, useCallback, useState } from 'react';
import { Loader2, Brain } from 'lucide-react';
import { useApp } from '../store/AppContext';
import {
  loadFaceModels,
  loadCocoModel,
  detectFaces,
  detectObjects,
  TRACKED_OBJECTS,
  SUSPICIOUS_OBJECTS,
  type DetectedFace,
  type DetectedObject,
} from '../lib/aiDetection';
import { sendWhatsAppAlerts, showAlertToast } from '../lib/alertService';

export default function MotionDetector() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const overlayRef = useRef<HTMLCanvasElement>(null);
  const motionCanvasRef = useRef<HTMLCanvasElement>(null);
  const prevFrameRef = useRef<ImageData | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animationRef = useRef<number>(0);
  const aiIntervalRef = useRef<number>(0);
  const pollIntervalRef = useRef<number>(0);
  const lastMotionAlertRef = useRef<number>(0);
  const lastFaceAlertRef = useRef<number>(0);
  const lastObjectAlertRef = useRef<number>(0);
  const facesRef = useRef<DetectedFace[]>([]);
  const objectsRef = useRef<DetectedObject[]>([]);

  const [modelsReady, setModelsReady] = useState(false);
  const [loadingModels, setLoadingModels] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  
  // Real-time backend connection state
  const [pythonStatus, setPythonStatus] = useState({
    activeFacesCount: 0,
    activeObjectsCount: 0,
    connected: false
  });

  const {
    isMonitoring,
    settings,
    detectedMotion,
    setDetectedMotion,
    setCurrentFrame,
    addAlert,
    authorizedFaces,
    backendMode,
    pythonServerUrl,
  } = useApp();

  // Load AI models on mount (for browser mode)
  useEffect(() => {
    let cancelled = false;
    setLoadingModels(true);
    Promise.all([loadFaceModels(), loadCocoModel()])
      .then(() => {
        if (!cancelled) {
          setModelsReady(true);
          setLoadingModels(false);
        }
      })
      .catch(err => {
        console.error('Failed to load AI models:', err);
        if (!cancelled) {
          setLoadError('AI models failed to load. Motion detection still active.');
          setLoadingModels(false);
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const startCamera = useCallback(async () => {
    if (backendMode === 'python') return; // Handled by Flask server
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'environment',
          frameRate: { ideal: 30 },
        },
      });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        streamRef.current = stream;
        if (videoRef.current) videoRef.current.srcObject = stream;
      } catch (err) {
        console.warn('Camera access denied:', err);
      }
    }
  }, [backendMode]);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) videoRef.current.srcObject = null;
    prevFrameRef.current = null;
    facesRef.current = [];
    objectsRef.current = [];
  }, []);

  const detectMotion = useCallback((frame: ImageData): number => {
    if (!prevFrameRef.current) {
      prevFrameRef.current = frame;
      return 0;
    }
    const prev = prevFrameRef.current.data;
    const curr = frame.data;
    const threshold = 50;
    let changed = 0;
    for (let i = 0; i < prev.length; i += 16) {
      const d =
        Math.abs(prev[i] - curr[i]) +
        Math.abs(prev[i + 1] - curr[i + 1]) +
        Math.abs(prev[i + 2] - curr[i + 2]);
      if (d > threshold * 2) changed++;
    }
    prevFrameRef.current = frame;
    const sampled = prev.length / 16;
    return (changed / sampled) * 100;
  }, []);

  const captureAnnotatedFrame = useCallback((): string => {
    const video = videoRef.current;
    if (!video || video.readyState < 2) return '';
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) return '';
    ctx.drawImage(video, 0, 0);

    // Draw face boxes
    facesRef.current.forEach(f => {
      const isUnknown = !f.matchedName;
      ctx.strokeStyle = isUnknown ? '#ef4444' : '#10b981';
      ctx.lineWidth = 3;
      ctx.strokeRect(f.box.x, f.box.y, f.box.width, f.box.height);
      ctx.fillStyle = isUnknown ? '#ef4444' : '#10b981';
      ctx.font = 'bold 14px sans-serif';
      const label = isUnknown ? 'UNKNOWN' : f.matchedName!;
      ctx.fillText(label, f.box.x, f.box.y - 6);
    });

    // Draw object boxes
    objectsRef.current.forEach(o => {
      const isSus = SUSPICIOUS_OBJECTS.has(o.class);
      ctx.strokeStyle = isSus ? '#f97316' : '#3b82f6';
      ctx.lineWidth = 2;
      ctx.strokeRect(...o.bbox);
      ctx.fillStyle = isSus ? '#f97316' : '#3b82f6';
      ctx.font = '12px sans-serif';
      ctx.fillText(`${o.class} ${(o.score * 100).toFixed(0)}%`, o.bbox[0], o.bbox[1] - 4);
    });

    return canvas.toDataURL('image/jpeg', 0.8);
  }, []);

  const renderOverlay = useCallback(() => {
    const video = videoRef.current;
    const overlay = overlayRef.current;
    if (!video || !overlay) return;

    const w = video.videoWidth || 640;
    const h = video.videoHeight || 480;
    if (overlay.width !== w) overlay.width = w;
    if (overlay.height !== h) overlay.height = h;

    const ctx = overlay.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, w, h);

    // Faces
    facesRef.current.forEach(f => {
      const isUnknown = !f.matchedName;
      ctx.strokeStyle = isUnknown ? '#ef4444' : '#10b981';
      ctx.lineWidth = 3;
      ctx.strokeRect(f.box.x, f.box.y, f.box.width, f.box.height);
      ctx.fillStyle = isUnknown ? 'rgba(239, 68, 68, 0.85)' : 'rgba(16, 185, 129, 0.85)';
      const label = isUnknown ? '⚠ UNKNOWN' : `✓ ${f.matchedName}`;
      ctx.font = 'bold 14px sans-serif';
      const tw = ctx.measureText(label).width + 10;
      ctx.fillRect(f.box.x, f.box.y - 22, tw, 22);
      ctx.fillStyle = '#fff';
      ctx.fillText(label, f.box.x + 5, f.box.y - 6);
    });

    // Objects
    objectsRef.current.forEach(o => {
      const isSus = SUSPICIOUS_OBJECTS.has(o.class);
      ctx.strokeStyle = isSus ? '#f97316' : '#3b82f6';
      ctx.lineWidth = 2;
      ctx.strokeRect(...o.bbox);
      ctx.fillStyle = isSus ? 'rgba(249, 115, 22, 0.85)' : 'rgba(59, 130, 246, 0.85)';
      const label = `${o.class} ${(o.score * 100).toFixed(0)}%`;
      ctx.font = '11px sans-serif';
      const tw = ctx.measureText(label).width + 8;
      ctx.fillRect(o.bbox[0], o.bbox[1] - 16, tw, 16);
      ctx.fillStyle = '#fff';
      ctx.fillText(label, o.bbox[0] + 4, o.bbox[1] - 4);
    });
  }, []);

  const motionLoop = useCallback(() => {
    const video = videoRef.current;
    const canvas = motionCanvasRef.current;
    if (!video || !canvas || video.readyState < 2) {
      animationRef.current = requestAnimationFrame(motionLoop);
      return;
    }

    const w = 160;
    const h = 120;
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) {
      animationRef.current = requestAnimationFrame(motionLoop);
      return;
    }
    ctx.drawImage(video, 0, 0, w, h);
    const frame = ctx.getImageData(0, 0, w, h);
    const motionPct = detectMotion(frame);

    const isMotion = motionPct > settings.motionSensitivity;
    if (isMotion !== detectedMotion) setDetectedMotion(isMotion);

    const now = Date.now();
    if (isMotion && now - lastMotionAlertRef.current > 8000) {
      lastMotionAlertRef.current = now;
      const snapshot = captureAnnotatedFrame();
      if (snapshot) {
        setCurrentFrame(snapshot);
        const severity = motionPct > 60 ? 'high' : motionPct > 40 ? 'medium' : 'low';
        const alert = {
          type: 'motion' as const,
          timestamp: new Date(),
          image: snapshot,
          message: `Motion detected (${Math.round(motionPct)}% scene change)`,
          severity: severity as 'low' | 'medium' | 'high' | 'critical',
        };
        addAlert(alert);
        if (settings.mobileNumbers.length > 0 && settings.alertEnabled) {
          const results = sendWhatsAppAlerts(settings.mobileNumbers, { ...alert, id: 'temp' });
          results.forEach(r => showAlertToast(r.formatted, !!r.window));
        }
      }
    }

    renderOverlay();
    animationRef.current = requestAnimationFrame(motionLoop);
  }, [
    detectedMotion,
    settings.motionSensitivity,
    detectMotion,
    setDetectedMotion,
    setCurrentFrame,
    addAlert,
    captureAnnotatedFrame,
    renderOverlay,
    settings.mobileNumbers,
    settings.alertEnabled,
  ]);

  const aiLoop = useCallback(async () => {
    const video = videoRef.current;
    if (!video || video.readyState < 2 || !modelsReady) return;

    const authorized = authorizedFaces
      .filter(f => f.descriptor)
      .map(f => ({ name: f.name, descriptor: f.descriptor as Float32Array }));

    try {
      const [faces, objects] = await Promise.all([
        detectFaces(video, authorized),
        detectObjects(video),
      ]);

      facesRef.current = faces;
      objectsRef.current = objects.filter(o => TRACKED_OBJECTS.has(o.class));

      const now = Date.now();

      // Unauthorized face alert
      const unknownFaces = faces.filter(f => !f.matchedName);
      if (unknownFaces.length > 0 && now - lastFaceAlertRef.current > 10000) {
        lastFaceAlertRef.current = now;
        const snapshot = captureAnnotatedFrame();
        if (snapshot) {
          setCurrentFrame(snapshot);
          const alert = {
            type: 'unauthorized' as const,
            timestamp: new Date(),
            image: snapshot,
            message: `🚨 Unauthorized person detected (${unknownFaces.length} unknown face${unknownFaces.length > 1 ? 's' : ''})`,
            severity: (unknownFaces.length > 1 ? 'critical' : 'high') as 'low' | 'medium' | 'high' | 'critical',
          };
          addAlert(alert);
          if (settings.mobileNumbers.length > 0 && settings.alertEnabled) {
            const results = sendWhatsAppAlerts(settings.mobileNumbers, { ...alert, id: 'temp' });
            results.forEach(r => showAlertToast(r.formatted, !!r.window));
          }
        }
      }

      // Suspicious object alert
      const sus = objects.filter(o => SUSPICIOUS_OBJECTS.has(o.class));
      if (sus.length > 0 && now - lastObjectAlertRef.current > 10000) {
        lastObjectAlertRef.current = now;
        const snapshot = captureAnnotatedFrame();
        if (snapshot) {
          setCurrentFrame(snapshot);
          const alert = {
            type: 'suspicious' as const,
            timestamp: new Date(),
            image: snapshot,
            message: `⚠️ Suspicious object detected: ${sus.map(s => s.class).join(', ')}`,
            severity: 'critical' as const,
          };
          addAlert(alert);
          if (settings.mobileNumbers.length > 0 && settings.alertEnabled) {
            const results = sendWhatsAppAlerts(settings.mobileNumbers, { ...alert, id: 'temp' });
            results.forEach(r => showAlertToast(r.formatted, !!r.window));
          }
        }
      }
    } catch (err) {
      console.error('AI detection error:', err);
    }
  }, [modelsReady, authorizedFaces, captureAnnotatedFrame, setCurrentFrame, addAlert, settings.mobileNumbers, settings.alertEnabled]);

  // Python Backend status poll loop
  const pollBackendStatus = useCallback(async () => {
    try {
      const res = await fetch(`${pythonServerUrl}/api/status`);
      if (res.ok) {
        const data = await res.json();
        setPythonStatus({
          activeFacesCount: data.activeFaces?.length || 0,
          activeObjectsCount: data.activeObjects?.length || 0,
          connected: true
        });
        setDetectedMotion(data.motionDetected);
      }
    } catch {
      setPythonStatus(p => ({ ...p, connected: false }));
    }
  }, [pythonServerUrl, setDetectedMotion]);

  useEffect(() => {
    if (backendMode === 'python') {
      stopCamera();
      cancelAnimationFrame(animationRef.current);
      clearInterval(aiIntervalRef.current);
      
      if (isMonitoring) {
        // Start streaming status polling
        pollBackendStatus();
        pollIntervalRef.current = window.setInterval(pollBackendStatus, 1000);
        
        // Notify Python Backend to toggle start
        fetch(`${pythonServerUrl}/api/toggle`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ start: true })
        }).catch(err => console.error("Flask connect error:", err));
      } else {
        clearInterval(pollIntervalRef.current);
        fetch(`${pythonServerUrl}/api/toggle`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ start: false })
        }).catch(() => {});
      }
      return;
    }

    // Standard local Browser-based monitoring
    if (isMonitoring) {
      startCamera();
      animationRef.current = requestAnimationFrame(motionLoop);
      if (modelsReady) {
        aiIntervalRef.current = window.setInterval(aiLoop, 800);
      }
    } else {
      stopCamera();
      cancelAnimationFrame(animationRef.current);
      clearInterval(aiIntervalRef.current);
      setDetectedMotion(false);
    }

    return () => {
      stopCamera();
      cancelAnimationFrame(animationRef.current);
      clearInterval(aiIntervalRef.current);
      clearInterval(pollIntervalRef.current);
    };
  }, [isMonitoring, backendMode, modelsReady, startCamera, stopCamera, motionLoop, aiLoop, setDetectedMotion, pythonServerUrl, pollBackendStatus]);

  return (
    <div className="relative overflow-hidden rounded-xl bg-black">
      <div className="relative">
        {backendMode === 'python' ? (
          isMonitoring && pythonStatus.connected ? (
            <img
              src={`${pythonServerUrl}/video_feed`}
              alt="Python OpenCV Surveillance Feed"
              className="w-full object-cover"
              style={{ minHeight: '360px', maxHeight: '70vh' }}
            />
          ) : (
            <div className="flex flex-col items-center justify-center bg-slate-900 text-center" style={{ minHeight: '360px' }}>
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-slate-800 animate-pulse">
                <svg className="h-8 w-8 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0" />
                </svg>
              </div>
              <p className="text-sm text-slate-400">
                {!isMonitoring ? 'Click "Start Monitoring" to connect' : 'Python Server Disconnected'}
              </p>
              {isMonitoring && (
                <p className="mt-2 text-xs text-slate-500">
                  Ensure the Flask app is running at <span className="text-blue-400">{pythonServerUrl}</span>
                </p>
              )}
            </div>
          )
        ) : (
          <>
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full object-cover"
              style={{ minHeight: '360px', maxHeight: '70vh' }}
            />
            <canvas
              ref={overlayRef}
              className="absolute inset-0 w-full h-full pointer-events-none"
              style={{ minHeight: '360px', maxHeight: '70vh' }}
            />
          </>
        )}
      </div>
      <canvas ref={motionCanvasRef} className="hidden" />

      {/* Loading state (Only in browser mode) */}
      {backendMode === 'browser' && loadingModels && (
        <div className="absolute top-3 left-3 flex items-center gap-2 rounded-full bg-blue-500/90 px-3 py-1.5 text-xs font-bold text-white">
          <Loader2 className="h-3 w-3 animate-spin" />
          Loading Local AI...
        </div>
      )}

      {backendMode === 'browser' && !loadingModels && modelsReady && (
        <div className="absolute top-3 left-3 flex items-center gap-2 rounded-full bg-purple-500/90 px-3 py-1.5 text-xs font-bold text-white">
          <Brain className="h-3 w-3" />
          Local AI Active
        </div>
      )}

      {backendMode === 'python' && isMonitoring && (
        <div className="absolute top-3 left-3 flex items-center gap-2 rounded-full bg-cyan-500/90 px-3 py-1.5 text-xs font-bold text-white">
          <Brain className="h-3 w-3" />
          Python OpenCV YOLO Feed
        </div>
      )}

      {loadError && backendMode === 'browser' && (
        <div className="absolute top-3 left-3 max-w-xs rounded-lg bg-amber-500/90 px-3 py-1.5 text-xs font-medium text-white">
          {loadError}
        </div>
      )}

      {/* Camera offline overlay */}
      {backendMode === 'browser' && !isMonitoring && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm">
          <div className="text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-slate-800">
              <svg className="h-8 w-8 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M6.827 6.175A2.31 2.31 0 015.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 00-1.134-.175 2.31 2.31 0 01-1.64-1.055l-.822-1.316a2.192 2.192 0 00-1.736-1.039 48.774 48.774 0 00-5.232 0 2.192 2.192 0 00-1.736 1.039l-.821 1.316z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 12.75a4.5 4.5 0 11-9 0 4.5 4.5 0 019 0z" />
              </svg>
            </div>
            <p className="text-sm text-slate-400">Click "Start Monitoring" to begin</p>
            {modelsReady && (
              <p className="mt-2 text-xs text-purple-400">✨ Local AI models loaded and ready</p>
            )}
          </div>
        </div>
      )}

      {/* Status indicators */}
      {isMonitoring && detectedMotion && (
        <div className="absolute top-3 right-3 flex items-center gap-2 rounded-full bg-red-500/90 px-3 py-1.5 text-xs font-bold text-white animate-pulse">
          <span className="h-2 w-2 rounded-full bg-white" />
          MOTION DETECTED
        </div>
      )}
      {isMonitoring && !detectedMotion && (
        <div className="absolute top-3 right-3 flex items-center gap-2 rounded-full bg-emerald-500/90 px-3 py-1.5 text-xs font-bold text-white">
          <span className="h-2 w-2 rounded-full bg-white" />
          MONITORING
        </div>
      )}

      {/* Detection counts */}
      {isMonitoring && (
        <div className="absolute bottom-3 left-3 flex gap-2">
          <div className="flex items-center gap-1.5 rounded-full bg-black/70 px-3 py-1 text-xs font-medium text-white backdrop-blur-sm">
            <span className="h-2 w-2 rounded-full bg-blue-400" />
            {backendMode === 'python' ? pythonStatus.activeObjectsCount : objectsRef.current.length} objects
          </div>
          <div className="flex items-center gap-1.5 rounded-full bg-black/70 px-3 py-1 text-xs font-medium text-white backdrop-blur-sm">
            <span className="h-2 w-2 rounded-full bg-emerald-400" />
            {backendMode === 'python' ? pythonStatus.activeFacesCount : facesRef.current.length} faces
          </div>
        </div>
      )}
    </div>
  );
}
