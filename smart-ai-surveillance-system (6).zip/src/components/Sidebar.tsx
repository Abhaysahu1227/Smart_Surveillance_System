import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Image,
  Bell,
  Settings,
  Shield,
  Radio,
  AlertTriangle,
  LogOut,
  ChevronDown,
} from 'lucide-react';
import { useState } from 'react';
import { useApp } from '../store/AppContext';
import { useAuth } from '../store/AuthContext';
import { cn } from '../utils/cn';

const navItems = [
  { to: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/gallery', icon: Image, label: 'Gallery' },
  { to: '/alerts', icon: Bell, label: 'Alerts' },
  { to: '/settings', icon: Settings, label: 'Settings' },
];

const roleColors: Record<string, string> = {
  admin: 'bg-blue-500/20 text-blue-400',
  operator: 'bg-emerald-500/20 text-emerald-400',
  viewer: 'bg-amber-500/20 text-amber-400',
};

export default function Sidebar() {
  const { alerts, detectedMotion } = useApp();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [showUserMenu, setShowUserMenu] = useState(false);

  const criticalAlerts = alerts.filter(
    a => a.severity === 'critical' || a.severity === 'high'
  ).length;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <aside className="fixed left-0 top-0 z-40 flex h-full w-64 flex-col border-r border-slate-700/50 bg-slate-900">
      {/* Logo */}
      <div className="flex items-center gap-3 border-b border-slate-700/50 px-6 py-5">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 shadow-lg shadow-blue-500/20">
          <Shield className="h-5 w-5 text-white" />
        </div>
        <div>
          <h1 className="text-lg font-bold tracking-tight text-white">
            Smart Surveillance
          </h1>
          <p className="text-xs text-slate-400">System</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-1 px-3 py-6">
        {navItems.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            end={to === '/'}
            className={({ isActive }) =>
              cn(
                'flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition-all duration-200',
                isActive
                  ? 'bg-blue-600/20 text-blue-400 shadow-sm'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
              )
            }
          >
            <Icon className="h-5 w-5" />
            <span>{label}</span>
            {label === 'Alerts' && criticalAlerts > 0 && (
              <span className="ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-red-500 px-1.5 text-xs font-bold text-white">
                {criticalAlerts}
              </span>
            )}
          </NavLink>
        ))}
      </nav>

      {/* System Status */}
      <div className="px-4 pb-2">
        <div className="flex items-center gap-3 rounded-lg bg-slate-800/50 px-4 py-3">
          <div
            className={cn(
              'flex h-8 w-8 items-center justify-center rounded-full',
              detectedMotion ? 'bg-red-500 animate-pulse' : 'bg-emerald-500'
            )}
          >
            <Radio className="h-4 w-4 text-white" />
          </div>
          <div>
            <p className="text-xs font-medium text-slate-300">System Status</p>
            <p
              className={cn(
                'text-xs font-semibold',
                detectedMotion ? 'text-red-400' : 'text-emerald-400'
              )}
            >
              {detectedMotion ? (
                <span className="flex items-center gap-1">
                  <AlertTriangle className="h-3 w-3" /> Motion Detected
                </span>
              ) : (
                'All Clear'
              )}
            </p>
          </div>
        </div>
      </div>

      {/* User Profile & Logout */}
      <div className="relative border-t border-slate-700/50 px-4 py-4">
        <button
          onClick={() => setShowUserMenu(p => !p)}
          className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left transition-all hover:bg-slate-800"
        >
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 text-sm font-bold text-white uppercase shadow-md">
            {user?.name?.charAt(0) || 'U'}
          </div>
          <div className="flex-1 min-w-0">
            <p className="truncate text-sm font-medium text-slate-200">
              {user?.name || 'User'}
            </p>
            <span
              className={cn(
                'inline-flex items-center rounded-full px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider',
                roleColors[user?.role || 'viewer']
              )}
            >
              {user?.role || 'viewer'}
            </span>
          </div>
          <ChevronDown
            className={cn(
              'h-4 w-4 text-slate-500 transition-transform',
              showUserMenu && 'rotate-180'
            )}
          />
        </button>

        {/* Dropdown Menu */}
        {showUserMenu && (
          <div className="absolute bottom-full left-4 right-4 mb-2 overflow-hidden rounded-xl border border-slate-700 bg-slate-800 shadow-2xl animate-in fade-in slide-in-from-bottom-2 duration-150">
            <div className="border-b border-slate-700/50 px-4 py-3">
              <p className="text-xs text-slate-500">Signed in as</p>
              <p className="truncate text-sm font-semibold text-white">
                {user?.username || 'unknown'}
              </p>
            </div>
            <div className="p-1.5">
              <button
                onClick={handleLogout}
                className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-red-400 transition-all hover:bg-red-500/10"
              >
                <LogOut className="h-4 w-4" />
                Sign out
              </button>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}
