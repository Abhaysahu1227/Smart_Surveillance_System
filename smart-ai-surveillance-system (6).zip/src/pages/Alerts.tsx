import { useState } from 'react';
import { Bell, AlertTriangle, AlertCircle, Info, X, Trash2, Filter } from 'lucide-react';
import { useApp } from '../store/AppContext';
import { cn } from '../utils/cn';
import type { Alert } from '../types';

const severityConfig: Record<Alert['severity'], { icon: typeof AlertTriangle; color: string; bg: string; label: string }> = {
  critical: { icon: AlertTriangle, color: 'text-red-400', bg: 'bg-red-500/20', label: 'Critical' },
  high: { icon: AlertTriangle, color: 'text-orange-400', bg: 'bg-orange-500/20', label: 'High' },
  medium: { icon: AlertCircle, color: 'text-amber-400', bg: 'bg-amber-500/20', label: 'Medium' },
  low: { icon: Info, color: 'text-blue-400', bg: 'bg-blue-500/20', label: 'Low' },
};

const typeLabels: Record<Alert['type'], string> = {
  motion: 'Motion Detected',
  unauthorized: 'Unauthorized Person',
  suspicious: 'Suspicious Activity',
  intrusion: 'Intrusion Detected',
};

export default function AlertsPage() {
  const { alerts, clearAlerts } = useApp();
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null);
  const [filterSeverity, setFilterSeverity] = useState<'all' | Alert['severity']>('all');
  const [filterType, setFilterType] = useState<'all' | Alert['type']>('all');

  const filtered = alerts.filter(a => {
    if (filterSeverity !== 'all' && a.severity !== filterSeverity) return false;
    if (filterType !== 'all' && a.type !== filterType) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">Alerts</h2>
          <p className="text-sm text-slate-400">
            {alerts.length} total alerts · {alerts.filter(a => a.severity === 'critical' || a.severity === 'high').length} high priority
          </p>
        </div>
        {alerts.length > 0 && (
          <button
            onClick={clearAlerts}
            className="flex items-center gap-2 rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-2 text-sm font-medium text-red-400 hover:bg-red-500/20 transition-colors"
          >
            <Trash2 className="h-4 w-4" /> Clear All
          </button>
        )}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        <div className="flex items-center gap-2 rounded-lg border border-slate-700/50 bg-slate-800/50 px-3 py-2">
          <Filter className="h-4 w-4 text-slate-400" />
          <select
            value={filterSeverity}
            onChange={e => setFilterSeverity(e.target.value as typeof filterSeverity)}
            className="bg-transparent text-sm text-slate-300 focus:outline-none"
          >
            <option value="all">All Severities</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
        <div className="flex items-center gap-2 rounded-lg border border-slate-700/50 bg-slate-800/50 px-3 py-2">
          <select
            value={filterType}
            onChange={e => setFilterType(e.target.value as typeof filterType)}
            className="bg-transparent text-sm text-slate-300 focus:outline-none"
          >
            <option value="all">All Types</option>
            <option value="motion">Motion</option>
            <option value="unauthorized">Unauthorized</option>
            <option value="suspicious">Suspicious</option>
            <option value="intrusion">Intrusion</option>
          </select>
        </div>
      </div>

      {/* Alerts List */}
      {filtered.length > 0 ? (
        <div className="space-y-2">
          {filtered.map(alert => {
            const config = severityConfig[alert.severity];
            const Icon = config.icon;
            return (
              <div
                key={alert.id}
                onClick={() => setSelectedAlert(alert)}
                className={cn(
                  'cursor-pointer rounded-xl border p-4 transition-all hover:shadow-lg',
                  alert.severity === 'critical'
                    ? 'border-red-500/30 bg-red-500/5 hover:bg-red-500/10'
                    : alert.severity === 'high'
                    ? 'border-orange-500/30 bg-orange-500/5 hover:bg-orange-500/10'
                    : alert.severity === 'medium'
                    ? 'border-amber-500/30 bg-amber-500/5 hover:bg-amber-500/10'
                    : 'border-slate-700/50 bg-slate-800/30 hover:bg-slate-800/50'
                )}
              >
                <div className="flex items-start gap-4">
                  <div className={cn('flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg', config.bg)}>
                    <Icon className={cn('h-5 w-5', config.color)} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1">
                      <span className="font-medium text-slate-200">{alert.message}</span>
                      <span className={cn('rounded-full px-2 py-0.5 text-xs font-medium', config.bg, config.color)}>
                        {config.label}
                      </span>
                    </div>
                    <p className="text-sm text-slate-400">{typeLabels[alert.type]}</p>
                    <p className="text-xs text-slate-500 mt-1">
                      {new Date(alert.timestamp).toLocaleString()}
                    </p>
                  </div>
                  {alert.image && (
                    <img
                      src={alert.image}
                      alt="Alert"
                      className="h-16 w-24 rounded-lg object-cover flex-shrink-0 border border-slate-700"
                    />
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-slate-700 py-20">
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-slate-800">
            <Bell className="h-8 w-8 text-slate-600" />
          </div>
          <h3 className="text-lg font-medium text-slate-400">No alerts</h3>
          <p className="mt-1 text-sm text-slate-500">
            Alerts will appear here when motion or suspicious activity is detected
          </p>
        </div>
      )}

      {/* Alert Detail Modal */}
      {selectedAlert && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
          onClick={() => setSelectedAlert(null)}
        >
          <div
            className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-700/50 p-6">
              <h3 className="text-lg font-semibold text-white">Alert Details</h3>
              <button
                onClick={() => setSelectedAlert(null)}
                className="rounded-lg p-1 text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              {selectedAlert.image && (
                <img
                  src={selectedAlert.image}
                  alt="Alert detail"
                  className="w-full rounded-xl border border-slate-700"
                />
              )}
              <div>
                <p className="text-lg font-medium text-white">{selectedAlert.message}</p>
                <p className="text-sm text-slate-400">{typeLabels[selectedAlert.type]}</p>
              </div>
              <div className="flex gap-4 text-sm">
                <div>
                  <span className="text-slate-500">Time: </span>
                  <span className="text-slate-300">{new Date(selectedAlert.timestamp).toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-slate-500">Severity: </span>
                  <span className={cn('font-medium', severityConfig[selectedAlert.severity].color)}>
                    {severityConfig[selectedAlert.severity].label}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
