import { useState, useRef, useEffect } from 'react';
import { Play, Square, Shield, Eye, Camera, Activity, AlertTriangle, Zap } from 'lucide-react';
import MotionDetector from '../components/MotionDetector';
import { useApp } from '../store/AppContext';
import { useAuth } from '../store/AuthContext';
import { cn } from '../utils/cn';
import { sendWhatsAppAlerts, showAlertToast } from '../lib/alertService';

export default function Dashboard() {
  const { isMonitoring, toggleMonitoring, alerts, currentFrame, addAlert, setCurrentFrame, settings } = useApp();
  const { user } = useAuth();
  const [simulating, setSimulating] = useState(false);

  // FPS Counter State — tracks actual video frame processing
  const [currentFps, setCurrentFps] = useState(0);
  const frameCountRef = useRef(0);
  const lastFpsTimeRef = useRef(Date.now());
  const animFrameRef = useRef<number>(0);
  const prevTimeRef = useRef(0);

  useEffect(() => {
    if (!isMonitoring) {
      setCurrentFps(0);
      cancelAnimationFrame(animFrameRef.current);
      return;
    }

    // Use requestVideoFrameCallback if available (accurate video FPS)
    // Fallback to rAF loop otherwise
    const videoEl = document.querySelector('video');
    if (videoEl && 'requestVideoFrameCallback' in videoEl) {
      const onVideoFrame = () => {
        frameCountRef.current++;
        const now = Date.now();
        if (now - lastFpsTimeRef.current >= 1000) {
          const fps = Math.round((frameCountRef.current * 1000) / (now - lastFpsTimeRef.current));
          setCurrentFps(fps);
          frameCountRef.current = 0;
          lastFpsTimeRef.current = now;
        }
        videoEl.requestVideoFrameCallback(onVideoFrame);
      };
      videoEl.requestVideoFrameCallback(onVideoFrame);
    } else {
      // Fallback: count rAF frames where video is ready
      const tick = () => {
        const video = document.querySelector('video');
        if (video && video.readyState >= 2) {
          const currentTime = video.currentTime;
          if (currentTime !== prevTimeRef.current) {
            frameCountRef.current++;
            prevTimeRef.current = currentTime;
          }
        }
        const now = Date.now();
        if (now - lastFpsTimeRef.current >= 1000) {
          const fps = Math.round((frameCountRef.current * 1000) / (now - lastFpsTimeRef.current));
          setCurrentFps(fps);
          frameCountRef.current = 0;
          lastFpsTimeRef.current = now;
        }
        animFrameRef.current = requestAnimationFrame(tick);
      };
      animFrameRef.current = requestAnimationFrame(tick);
    }

    return () => cancelAnimationFrame(animFrameRef.current);
  }, [isMonitoring]);
  
  const recentAlerts = alerts.slice(0, 5);
  const todayAlerts = alerts.filter(
    a => new Date(a.timestamp).toDateString() === new Date().toDateString()
  ).length;

  const simulateIntruder = () => {
    setSimulating(true);
    
    // Grab current video frame for realistic simulation
    const videoEl = document.querySelector('video');
    let snapshot = '';
    
    if (videoEl && videoEl.readyState >= 2) {
      const canvas = document.createElement('canvas');
      canvas.width = videoEl.videoWidth || 640;
      canvas.height = videoEl.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoEl, 0, 0);
        // Draw motion indicators
        ctx.fillStyle = 'rgba(255, 0, 0, 0.15)';
        const zoneX = canvas.width * 0.25 + Math.random() * canvas.width * 0.3;
        const zoneY = canvas.height * 0.2 + Math.random() * canvas.height * 0.3;
        ctx.fillRect(zoneX, zoneY, 120, 160);
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 3;
        ctx.strokeRect(zoneX, zoneY, 120, 160);
        ctx.fillStyle = '#ef4444';
        ctx.font = 'bold 16px sans-serif';
        ctx.fillText('⚠ INTRUSION', zoneX + 5, zoneY - 10);
        
        snapshot = canvas.toDataURL('image/jpeg', 0.8);
      }
    } else {
      // Generate a simulated dark frame
      const canvas = document.createElement('canvas');
      canvas.width = 640;
      canvas.height = 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#1a1a2e';
        ctx.fillRect(0, 0, 640, 480);
        ctx.fillStyle = 'rgba(255, 0, 0, 0.15)';
        ctx.fillRect(200, 100, 150, 200);
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 3;
        ctx.strokeRect(200, 100, 150, 200);
        ctx.fillStyle = '#ef4444';
        ctx.font = 'bold 16px sans-serif';
        ctx.fillText('⚠ INTRUSION', 210, 90);
        ctx.fillStyle = '#fff';
        ctx.font = '12px sans-serif';
        ctx.fillText('Suspicious person detected', 210, 320);
        snapshot = canvas.toDataURL('image/jpeg', 0.8);
      }
    }
    
    setCurrentFrame(snapshot);
    
    const alertTypes = [
      {
        type: 'intrusion' as const,
        message: '🚨 Perimeter breach detected! Unauthorized entry at main gate.',
        severity: 'critical' as const,
      },
      {
        type: 'unauthorized' as const,
        message: '👤 Unauthorized person detected in restricted area.',
        severity: 'high' as const,
      },
      {
        type: 'suspicious' as const,
        message: '⚠️ Suspicious loitering detected near entry point.',
        severity: 'medium' as const,
      },
      {
        type: 'intrusion' as const,
        message: '🔴 Multiple unauthorized individuals detected in camera zone.',
        severity: 'critical' as const,
      },
    ];
    
    const alertData = alertTypes[Math.floor(Math.random() * alertTypes.length)];
    const fullAlert = {
      ...alertData,
      timestamp: new Date(),
      image: snapshot,
    };
    
    addAlert(fullAlert);
    
    // Send WhatsApp alerts if configured
    if (settings.mobileNumbers.length > 0 && settings.alertEnabled) {
      const results = sendWhatsAppAlerts(settings.mobileNumbers, { ...fullAlert, id: 'temp' });
      results.forEach(r => showAlertToast(r.formatted, !!r.window));
    }
    
    setTimeout(() => setSimulating(false), 1500);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">
            Welcome, {user?.name?.split(' ')[0] || 'Operator'}
          </h2>
          <p className="text-sm text-slate-400">Real-time monitoring and threat detection</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={simulateIntruder}
            disabled={simulating}
            className={cn(
              'flex items-center gap-2 rounded-xl px-5 py-3 text-sm font-semibold transition-all duration-300 shadow-lg',
              'border border-amber-500/40 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20',
              simulating && 'opacity-50 cursor-not-allowed'
            )}
          >
            <Zap className="h-4 w-4" />
            {simulating ? 'Simulating...' : 'Simulate Intruder'}
          </button>
          <button
            onClick={toggleMonitoring}
            className={cn(
              'flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-semibold transition-all duration-300 shadow-lg',
              isMonitoring
                ? 'bg-red-500 text-white hover:bg-red-600 shadow-red-500/25'
                : 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white hover:from-cyan-400 hover:to-blue-500 shadow-blue-500/25'
            )}
          >
            {isMonitoring ? (
              <>
                <Square className="h-4 w-4" /> Stop Monitoring
              </>
            ) : (
              <>
                <Play className="h-4 w-4" /> Start Monitoring
              </>
            )}
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="rounded-xl border border-slate-700/50 bg-slate-800/50 p-4 backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-500/20">
              <Camera className="h-5 w-5 text-blue-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{isMonitoring ? 'Live' : 'Off'}</p>
              <p className="text-xs text-slate-400">Status</p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-slate-700/50 bg-slate-800/50 p-4 backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <div className={cn(
              'flex h-10 w-10 items-center justify-center rounded-lg',
              isMonitoring ? 'bg-purple-500/20' : 'bg-slate-700/50'
            )}>
              <Zap className={cn('h-5 w-5', isMonitoring ? 'text-purple-400' : 'text-slate-500')} />
            </div>
            <div className="flex-1">
              <div className="flex items-end justify-between">
                <p className={cn('text-2xl font-bold font-mono', isMonitoring ? 'text-purple-400' : 'text-slate-500')}>
                  {isMonitoring ? `${currentFps}` : '0'}
                </p>
                <p className="text-xs text-slate-400 mb-0.5">FPS</p>
              </div>
              {/* FPS Bar */}
              <div className="mt-2 h-1.5 w-full rounded-full bg-slate-700 overflow-hidden">
                <div
                  className={cn(
                    'h-full rounded-full transition-all duration-500 ease-out',
                    currentFps >= 50 ? 'bg-emerald-400' :
                    currentFps >= 30 ? 'bg-amber-400' :
                    currentFps >= 10 ? 'bg-orange-400' : 'bg-red-400'
                  )}
                  style={{ width: `${Math.min((currentFps / 60) * 100, 100)}%` }}
                />
              </div>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-slate-700/50 bg-slate-800/50 p-4 backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-500/20">
              <Eye className="h-5 w-5 text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{todayAlerts}</p>
              <p className="text-xs text-slate-400">Today Alerts</p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-slate-700/50 bg-slate-800/50 p-4 backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-500/20">
              <Shield className="h-5 w-5 text-purple-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{alerts.length}</p>
              <p className="text-xs text-slate-400">Total Alerts</p>
            </div>
          </div>
        </div>
      </div>



      {/* Live Feed */}
      <div className="overflow-hidden rounded-xl border border-slate-700/50 bg-slate-900 shadow-2xl">
        <MotionDetector />
      </div>

      {/* Snapshot + Recent Alerts */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Latest Snapshot */}
        <div className="rounded-xl border border-slate-700/50 bg-slate-800/50 p-4 backdrop-blur-sm">
          <h3 className="mb-4 flex items-center gap-2 text-sm font-semibold text-slate-300">
            <Camera className="h-4 w-4 text-blue-400" />
            Latest Capture
          </h3>
          {currentFrame ? (
            <div className="overflow-hidden rounded-lg border border-slate-700">
              <img src={currentFrame} alt="Latest capture" className="w-full object-cover" />
              <div className="bg-slate-900 px-3 py-2 flex items-center justify-between">
                <p className="text-xs text-slate-400">
                  Captured at {new Date().toLocaleTimeString()}
                </p>
                <span className="rounded-full bg-red-500/20 px-2 py-0.5 text-xs font-medium text-red-400 flex items-center gap-1">
                  <AlertTriangle className="h-3 w-3" />
                  Alert Triggered
                </span>
              </div>
            </div>
          ) : (
            <div className="flex h-48 items-center justify-center rounded-lg border border-dashed border-slate-700 text-sm text-slate-500">
              No captures yet. Motion will trigger snapshots.
            </div>
          )}
        </div>

        {/* Recent Alerts */}
        <div className="rounded-xl border border-slate-700/50 bg-slate-800/50 p-4 backdrop-blur-sm">
          <h3 className="mb-4 flex items-center gap-2 text-sm font-semibold text-slate-300">
            <Activity className="h-4 w-4 text-amber-400" />
            Recent Alerts
          </h3>
          {recentAlerts.length > 0 ? (
            <div className="space-y-2">
              {recentAlerts.map(alert => (
                <div
                  key={alert.id}
                  className={cn(
                    'flex items-center gap-3 rounded-lg border p-3 transition-colors',
                    alert.severity === 'critical' || alert.severity === 'high'
                      ? 'border-red-500/30 bg-red-500/10'
                      : alert.severity === 'medium'
                      ? 'border-amber-500/30 bg-amber-500/10'
                      : 'border-slate-700/50 bg-slate-900/50'
                  )}
                >
                  <div className={cn(
                    'h-2 w-2 rounded-full flex-shrink-0',
                    alert.severity === 'critical' || alert.severity === 'high' ? 'bg-red-500' :
                    alert.severity === 'medium' ? 'bg-amber-500' : 'bg-blue-500'
                  )} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-200 truncate">{alert.message}</p>
                    <p className="text-xs text-slate-500">
                      {new Date(alert.timestamp).toLocaleString()}
                    </p>
                  </div>
                  {alert.image && (
                    <img src={alert.image} alt="Alert" className="h-10 w-14 rounded object-cover flex-shrink-0" />
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="flex h-48 items-center justify-center rounded-lg border border-dashed border-slate-700 text-sm text-slate-500">
              No alerts yet. Start monitoring to detect activity.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
