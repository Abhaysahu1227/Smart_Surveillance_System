import { useState } from 'react';
import { Image, X, Download, Search } from 'lucide-react';
import { useApp } from '../store/AppContext';
import { cn } from '../utils/cn';

export default function Gallery() {
  const { gallery } = useApp();
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | 'unauthorized' | 'suspicious'>('all');
  const [search, setSearch] = useState('');

  const filtered = gallery.filter(item => {
    if (filter !== 'all' && item.type !== filter) return false;
    if (search && item.label && !item.label.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const handleDownload = (src: string) => {
    const link = document.createElement('a');
    link.href = src;
    link.download = `capture-${Date.now()}.jpg`;
    link.click();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">Gallery</h2>
          <p className="text-sm text-slate-400">
            {gallery.length} captures of unauthorized & suspicious activity
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex rounded-lg border border-slate-700/50 bg-slate-800/50 p-1">
          {(['all', 'unauthorized', 'suspicious'] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                'rounded-md px-4 py-2 text-xs font-medium capitalize transition-all',
                filter === f
                  ? 'bg-blue-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              )}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="relative flex-1 min-w-[200px] max-w-xs">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input
            type="text"
            placeholder="Search by label..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full rounded-lg border border-slate-700/50 bg-slate-800/50 py-2 pl-10 pr-4 text-sm text-slate-200 placeholder:text-slate-500 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Gallery Grid */}
      {filtered.length > 0 ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map(item => (
            <div
              key={item.id}
              className="group relative overflow-hidden rounded-xl border border-slate-700/50 bg-slate-800/50 transition-all hover:border-slate-600 hover:shadow-xl"
            >
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={item.image}
                  alt={item.label || 'Capture'}
                  className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  onClick={() => setSelectedImage(item.image)}
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
              
              <div className="absolute bottom-0 left-0 right-0 p-3 translate-y-full transition-transform group-hover:translate-y-0">
                <div className="flex items-center justify-between">
                  <span className={cn(
                    'rounded-full px-2 py-0.5 text-xs font-medium',
                    item.type === 'unauthorized'
                      ? 'bg-red-500/20 text-red-300'
                      : 'bg-amber-500/20 text-amber-300'
                  )}>
                    {item.label || item.type}
                  </span>
                  <span className="text-xs text-slate-400">
                    {new Date(item.timestamp).toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="absolute right-2 top-2 flex gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                <button
                  onClick={() => handleDownload(item.image)}
                  className="rounded-lg bg-slate-900/80 p-2 text-slate-300 hover:text-white backdrop-blur-sm"
                  title="Download"
                >
                  <Download className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-slate-700 py-20">
          <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-slate-800">
            <Image className="h-8 w-8 text-slate-600" />
          </div>
          <h3 className="text-lg font-medium text-slate-400">No captures yet</h3>
          <p className="mt-1 text-sm text-slate-500">
            Images of unauthorized persons and suspicious activity will appear here
          </p>
        </div>
      )}

      {/* Modal */}
      {selectedImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
          onClick={() => setSelectedImage(null)}
        >
          <button
            onClick={() => setSelectedImage(null)}
            className="absolute right-6 top-6 rounded-full bg-slate-800/80 p-2 text-white hover:bg-slate-700"
          >
            <X className="h-6 w-6" />
          </button>
          <div className="relative max-h-[90vh] max-w-4xl" onClick={e => e.stopPropagation()}>
            <img
              src={selectedImage}
              alt="Preview"
              className="max-h-[85vh] max-w-full rounded-xl object-contain"
            />
            <div className="absolute bottom-4 right-4 flex gap-2">
              <button
                onClick={() => handleDownload(selectedImage)}
                className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
              >
                <Download className="h-4 w-4" /> Download
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
