import { useState, useRef } from 'react';
import {
  Phone,
  UserPlus,
  Plus,
  Trash2,
  Shield,
  Camera,
  Upload,
  Check,
  AlertTriangle,
  Loader2,
  Send,
  Server,
  Smartphone,
  Users,
  Key,
} from 'lucide-react';
import { useApp } from '../store/AppContext';
import { useAuth } from '../store/AuthContext';
import { cn } from '../utils/cn';
import { computeFaceDescriptor } from '../lib/aiDetection';
import { sendWhatsAppAlerts, createTestAlert, showAlertToast } from '../lib/alertService';

export default function SettingsPage() {
  const {
    settings,
    updateSettings,
    authorizedFaces,
    addAuthorizedFace,
    removeAuthorizedFace,
    backendMode,
    setBackendMode,
    pythonServerUrl,
    setPythonServerUrl,
  } = useApp();

  const { user, usersList, addUser, deleteUser, changePassword, error, clearError } = useAuth();

  const [phoneInput, setPhoneInput] = useState('');
  const [faceName, setFaceName] = useState('');
  const [saved, setSaved] = useState(false);
  const [faceImage, setFaceImage] = useState<string | null>(null);
  const [processingFace, setProcessingFace] = useState(false);
  const [faceError, setFaceError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAddPhone = () => {
    const cleaned = phoneInput.replace(/\D/g, '');
    if (cleaned.length < 10) return;
    if (settings.mobileNumbers.includes(cleaned)) return;
    updateSettings({ mobileNumbers: [...settings.mobileNumbers, cleaned] });
    setPhoneInput('');
    showSaved();
  };

  const handleRemovePhone = (num: string) => {
    updateSettings({ mobileNumbers: settings.mobileNumbers.filter(n => n !== num) });
    showSaved();
  };

  const handleAddFace = async () => {
    if (!faceName.trim() || !faceImage) return;
    setProcessingFace(true);
    setFaceError(null);
    try {
      if (backendMode === 'python') {
        // Enforce/send face to python server if in python mode
        const res = await fetch(`${pythonServerUrl}/api/faces`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: faceName.trim(), image: faceImage })
        });
        if (!res.ok) throw new Error('Backend failed to process facial encode.');
      }

      // Compute descriptor locally (for dual fallback support)
      const descriptor = await computeFaceDescriptor(faceImage);
      addAuthorizedFace({
        name: faceName.trim(),
        image: faceImage,
        descriptor: descriptor || undefined,
      });

      setFaceName('');
      setFaceImage(null);
      showSaved();
    } catch (err) {
      console.error(err);
      setFaceError('Failed to process face. Ensure backend is running if in Python mode.');
    } finally {
      setProcessingFace(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setFaceImage(ev.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const showSaved = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const formatPhone = (num: string) => {
    if (num.length === 10) return `+91 ${num.slice(0,5)} ${num.slice(5)}`;
    if (num.length > 10) return `+${num.slice(0,2)} ${num.slice(2,7)} ${num.slice(7)}`;
    return num;
  };

  const handleTestAlert = () => {
    if (settings.mobileNumbers.length === 0) return;
    const testAlert = createTestAlert();
    const results = sendWhatsAppAlerts(settings.mobileNumbers, testAlert);
    results.forEach(r => showAlertToast(r.formatted, !!r.window));
  };

  // User Management State
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<'admin' | 'operator' | 'viewer'>('viewer');
  
  const [targetUserId, setTargetUserId] = useState<string | null>(null);
  const [targetPassword, setTargetPassword] = useState('');

  const handleAddUser = () => {
    if (!newUsername.trim() || !newPassword.trim() || !newName.trim()) return;
    const success = addUser({ username: newUsername, name: newName, role: newRole }, newPassword);
    if (success) {
      setNewUsername('');
      setNewPassword('');
      setNewName('');
      setNewRole('viewer');
      showSaved();
    }
  };

  const handlePasswordChange = () => {
    if (!targetUserId || !targetPassword.trim()) return;
    const success = changePassword(targetUserId, targetPassword);
    if (success) {
      setTargetUserId(null);
      setTargetPassword('');
      showSaved();
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-white">Settings</h2>
        <p className="text-sm text-slate-400">Configure surveillance system and alert preferences</p>
      </div>

      {/* Backend Mode Configuration */}
      <div className="rounded-xl border border-slate-700/50 bg-slate-800/50 p-6 backdrop-blur-sm">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-500/20">
            <Server className="h-5 w-5 text-indigo-400" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Surveillance Engine</h3>
            <p className="text-sm text-slate-400">Choose between local browser-only processing or Python OpenCV/YOLO backend streaming</p>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 mb-6">
          <button
            onClick={() => {
              setBackendMode('browser');
              showSaved();
            }}
            className={cn(
              'flex flex-col items-start gap-2 rounded-xl border p-4 text-left transition-all',
              backendMode === 'browser'
                ? 'border-indigo-500 bg-indigo-500/10 ring-1 ring-indigo-500'
                : 'border-slate-700 bg-slate-900/50 hover:border-slate-600'
            )}
          >
            <Smartphone className="h-5 w-5 text-indigo-400" />
            <span className="font-semibold text-white text-sm">Standalone Browser Mode</span>
            <span className="text-xs text-slate-400">Processes frames locally via Tensorflow.js and WebAssembly models. Great for standalone testing.</span>
          </button>

          <button
            onClick={() => {
              setBackendMode('python');
              showSaved();
            }}
            className={cn(
              'flex flex-col items-start gap-2 rounded-xl border p-4 text-left transition-all',
              backendMode === 'python'
                ? 'border-indigo-500 bg-indigo-500/10 ring-1 ring-indigo-500'
                : 'border-slate-700 bg-slate-900/50 hover:border-slate-600'
            )}
          >
            <Server className="h-5 w-5 text-indigo-400" />
            <span className="font-semibold text-white text-sm">Python OpenCV & YOLO Server</span>
            <span className="text-xs text-slate-400">Streams live OpenCV feed annotated with ultra-fast PyTorch YOLOv8 object and dlib face recognition models.</span>
          </button>
        </div>

        {backendMode === 'python' && (
          <div className="space-y-2 animate-in fade-in duration-300">
            <label className="text-xs font-semibold text-slate-300">Python Flask Server Endpoint URL</label>
            <input
              type="url"
              value={pythonServerUrl}
              onChange={e => setPythonServerUrl(e.target.value)}
              placeholder="e.g. http://localhost:5000"
              className="w-full max-w-md rounded-lg border border-slate-600 bg-slate-900 px-4 py-2 text-sm text-slate-200 placeholder:text-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
            <p className="text-xs text-slate-500">Must match the IP address and port where your `app.py` is running.</p>
          </div>
        )}
      </div>

      {/* WhatsApp Alert Settings */}
      <div className="rounded-xl border border-slate-700/50 bg-slate-800/50 p-6 backdrop-blur-sm">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/20">
            <Phone className="h-5 w-5 text-emerald-400" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">WhatsApp Alert Numbers</h3>
            <p className="text-sm text-slate-400">Add mobile numbers to receive WhatsApp alerts</p>
          </div>
        </div>

        <div className="flex gap-3 mb-4">
          <input
            type="tel"
            value={phoneInput}
            onChange={e => setPhoneInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleAddPhone()}
            placeholder="Enter 10-digit mobile number"
            className="flex-1 rounded-lg border border-slate-600 bg-slate-900 px-4 py-2.5 text-sm text-slate-200 placeholder:text-slate-500 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
          />
          <button
            onClick={handleAddPhone}
            className="flex items-center gap-2 rounded-lg bg-emerald-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-500/20"
          >
            <Plus className="h-4 w-4" /> Add
          </button>
          {settings.mobileNumbers.length > 0 && (
            <button
              onClick={handleTestAlert}
              disabled={!settings.alertEnabled}
              className="flex items-center gap-2 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-4 py-2.5 text-sm font-medium text-emerald-400 hover:bg-emerald-500/20 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <Send className="h-4 w-4" /> Test Alert
            </button>
          )}
        </div>

        {settings.mobileNumbers.length > 0 ? (
          <div className="space-y-2">
            {settings.mobileNumbers.map(num => (
              <div
                key={num}
                className="flex items-center justify-between rounded-lg border border-slate-700/50 bg-slate-900/50 px-4 py-3"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-500/20">
                    <Phone className="h-4 w-4 text-emerald-400" />
                  </div>
                  <span className="text-sm font-medium text-slate-200">{formatPhone(num)}</span>
                  <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-xs text-emerald-400">
                    WhatsApp
                  </span>
                </div>
                <button
                  onClick={() => handleRemovePhone(num)}
                  className="rounded-lg p-2 text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="rounded-lg border border-dashed border-slate-700 py-8 text-center">
            <Phone className="mx-auto h-8 w-8 text-slate-600 mb-2" />
            <p className="text-sm text-slate-500">No numbers added yet</p>
          </div>
        )}
      </div>

      {/* Authorized Faces */}
      <div className="rounded-xl border border-slate-700/50 bg-slate-800/50 p-6 backdrop-blur-sm">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-500/20">
            <UserPlus className="h-5 w-5 text-blue-400" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Authorized Faces</h3>
            <p className="text-sm text-slate-400">Add faces of authorized persons for recognition</p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 mb-4">
          <input
            type="text"
            value={faceName}
            onChange={e => setFaceName(e.target.value)}
            placeholder="Person's name"
            className="flex-1 rounded-lg border border-slate-600 bg-slate-900 px-4 py-2.5 text-sm text-slate-200 placeholder:text-slate-500 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            capture="user"
            onChange={handleImageUpload}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className={cn(
              'flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-colors',
              faceImage
                ? 'bg-emerald-600 text-white'
                : 'border border-slate-600 text-slate-300 hover:bg-slate-700'
            )}
          >
            {faceImage ? <Check className="h-4 w-4" /> : <Upload className="h-4 w-4" />}
            {faceImage ? 'Image Selected' : 'Upload Photo'}
          </button>
          <button
            onClick={handleAddFace}
            disabled={!faceName.trim() || !faceImage || processingFace}
            className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors shadow-lg shadow-blue-500/20"
          >
            {processingFace ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> Analyzing...
              </>
            ) : (
              <>
                <Plus className="h-4 w-4" /> Add Face
              </>
            )}
          </button>
        </div>

        {faceError && (
          <div className="mb-3 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-400">
            {faceError}
          </div>
        )}

        {faceImage && (
          <div className="mb-4 inline-block rounded-lg border border-slate-700 overflow-hidden">
            <img src={faceImage} alt="Preview" className="h-32 w-32 object-cover" />
          </div>
        )}

        {authorizedFaces.length > 0 ? (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {authorizedFaces.map(face => (
              <div
                key={face.id}
                className="flex items-center gap-3 rounded-lg border border-slate-700/50 bg-slate-900/50 p-3"
              >
                <img
                  src={face.image}
                  alt={face.name}
                  className="h-14 w-14 rounded-lg object-cover border border-slate-700"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-200 truncate">{face.name}</p>
                  <p className="text-xs text-emerald-400 flex items-center gap-1">
                    <Shield className="h-3 w-3" />
                    {face.descriptor ? 'Recognized' : 'Authorized'}
                  </p>
                </div>
                <button
                  onClick={() => removeAuthorizedFace(face.id)}
                  className="rounded-lg p-1.5 text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="rounded-lg border border-dashed border-slate-700 py-8 text-center">
            <Camera className="mx-auto h-8 w-8 text-slate-600 mb-2" />
            <p className="text-sm text-slate-500">No authorized faces added yet</p>
            <p className="text-xs text-slate-600 mt-1">Add faces to enable recognition</p>
          </div>
        )}
      </div>

      {/* User Access Management */}
      <div className="rounded-xl border border-slate-700/50 bg-slate-800/50 p-6 backdrop-blur-sm">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-orange-500/20">
            <Users className="h-5 w-5 text-orange-400" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">System Access Management</h3>
            <p className="text-sm text-slate-400">Manage dashboard users, roles, and passwords</p>
          </div>
        </div>

        {error && (
          <div className="mb-4 flex items-center justify-between rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-400">
            <span>{error}</span>
            <button onClick={clearError} className="text-red-500 hover:text-red-300">×</button>
          </div>
        )}

        {/* Existing Users List */}
        <div className="mb-8 space-y-2">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Registered Users</p>
          {usersList.map(u => (
            <div key={u.id} className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-lg border border-slate-700/50 bg-slate-900/50 p-3">
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-700 text-xs font-bold text-white uppercase">
                  {u.name.charAt(0)}
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-200">{u.name} <span className="text-slate-500 font-normal">(@{u.username})</span></p>
                  <p className={cn(
                    'text-xs font-semibold uppercase mt-0.5',
                    u.role === 'admin' ? 'text-blue-400' : u.role === 'operator' ? 'text-emerald-400' : 'text-amber-400'
                  )}>{u.role}</p>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2">
                {targetUserId === u.id ? (
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      placeholder="New password"
                      value={targetPassword}
                      onChange={e => setTargetPassword(e.target.value)}
                      className="w-32 rounded-lg border border-slate-600 bg-slate-900 px-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:border-orange-500 focus:outline-none"
                    />
                    <button onClick={handlePasswordChange} className="rounded bg-orange-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-orange-700">Save</button>
                    <button onClick={() => setTargetUserId(null)} className="rounded border border-slate-600 px-3 py-1.5 text-xs font-medium text-slate-300 hover:bg-slate-700">Cancel</button>
                  </div>
                ) : (
                  <>
                    {(user?.role === 'admin' || user?.id === u.id) && (
                      <button
                        onClick={() => setTargetUserId(u.id)}
                        className="flex items-center gap-1.5 rounded-lg border border-slate-600 bg-slate-800 px-3 py-1.5 text-xs font-medium text-slate-300 hover:bg-slate-700 hover:text-white"
                      >
                        <Key className="h-3 w-3" /> Password
                      </button>
                    )}
                    {user?.role === 'admin' && user?.id !== u.id && (
                      <button
                        onClick={() => {
                          if (deleteUser(u.id)) showSaved();
                        }}
                        className="rounded-lg p-1.5 text-slate-500 hover:bg-red-500/10 hover:text-red-400 transition-colors"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Add User Form (Admin Only) */}
        {user?.role === 'admin' && (
          <div className="rounded-lg border border-slate-700/50 bg-slate-900/30 p-4">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4">Add New User</p>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
              <input
                type="text"
                placeholder="Full Name"
                value={newName}
                onChange={e => setNewName(e.target.value)}
                className="col-span-1 rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:border-orange-500 focus:outline-none"
              />
              <input
                type="text"
                placeholder="Username"
                value={newUsername}
                onChange={e => setNewUsername(e.target.value)}
                className="col-span-1 rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:border-orange-500 focus:outline-none"
              />
              <input
                type="text"
                placeholder="Password"
                value={newPassword}
                onChange={e => setNewPassword(e.target.value)}
                className="col-span-1 rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-sm text-white placeholder:text-slate-500 focus:border-orange-500 focus:outline-none"
              />
              <select
                value={newRole}
                onChange={e => setNewRole(e.target.value as 'admin'|'operator'|'viewer')}
                className="col-span-1 rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-sm text-white focus:border-orange-500 focus:outline-none"
              >
                <option value="viewer">Viewer</option>
                <option value="operator">Operator</option>
                <option value="admin">Admin</option>
              </select>
              <button
                onClick={handleAddUser}
                disabled={!newUsername.trim() || !newPassword.trim() || !newName.trim()}
                className="col-span-1 flex items-center justify-center gap-2 rounded-lg bg-orange-600 px-4 py-2 text-sm font-medium text-white hover:bg-orange-700 disabled:opacity-50 transition-colors shadow-lg shadow-orange-500/20"
              >
                <UserPlus className="h-4 w-4" /> Add
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Detection Settings */}
      <div className="rounded-xl border border-slate-700/50 bg-slate-800/50 p-6 backdrop-blur-sm">
        <div className="flex items-center gap-3 mb-6">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-500/20">
            <AlertTriangle className="h-5 w-5 text-purple-400" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Detection Settings</h3>
            <p className="text-sm text-slate-400">Adjust motion sensitivity and alert behavior</p>
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium text-slate-300">Motion Sensitivity</label>
              <span className="text-sm text-slate-400">{settings.motionSensitivity}%</span>
            </div>
            <input
              type="range"
              min="5"
              max="80"
              value={settings.motionSensitivity}
              onChange={e => {
                updateSettings({ motionSensitivity: Number(e.target.value) });
                showSaved();
              }}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
            <div className="flex justify-between text-xs text-slate-500 mt-1">
              <span>Low (5%)</span>
              <span>High (80%)</span>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-slate-300">Alert Notifications</p>
              <p className="text-xs text-slate-500">Enable WhatsApp and in-app alerts</p>
            </div>
            <button
              onClick={() => {
                updateSettings({ alertEnabled: !settings.alertEnabled });
                showSaved();
              }}
              className={cn(
                'relative h-7 w-12 rounded-full transition-colors',
                settings.alertEnabled ? 'bg-emerald-500' : 'bg-slate-600'
              )}
            >
              <div className={cn(
                'absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition-transform',
                settings.alertEnabled ? 'left-[22px]' : 'left-0.5'
              )} />
            </button>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium text-slate-300">Detection Interval</label>
              <span className="text-sm text-slate-400">{settings.detectionInterval}ms</span>
            </div>
            <input
              type="range"
              min="200"
              max="3000"
              step="100"
              value={settings.detectionInterval}
              onChange={e => {
                updateSettings({ detectionInterval: Number(e.target.value) });
                showSaved();
              }}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
            <div className="flex justify-between text-xs text-slate-500 mt-1">
              <span>Fast (200ms)</span>
              <span>Slow (3000ms)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Save toast */}
      {saved && (
        <div className="fixed bottom-6 right-6 flex items-center gap-2 rounded-xl bg-emerald-500 px-4 py-3 text-sm font-medium text-white shadow-2xl animate-in slide-in-from-right">
          <Check className="h-4 w-4" />
          Settings saved
        </div>
      )}
    </div>
  );
}
