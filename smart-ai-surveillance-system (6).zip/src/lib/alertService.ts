import type { Alert } from '../types';

export interface WhatsAppAlertResult {
  number: string;
  formatted: string;
  url: string;
  window: Window | null;
}

function formatPhoneForWhatsApp(num: string): string {
  // Remove all non-digits
  const cleaned = num.replace(/\D/g, '');
  
  // If it's a 10-digit Indian number, add +91
  if (cleaned.length === 10) {
    return `91${cleaned}`;
  }
  
  // If it starts with 0, remove it
  if (cleaned.startsWith('0')) {
    return cleaned.slice(1);
  }
  
  return cleaned;
}

function formatDisplayNumber(num: string): string {
  const cleaned = num.replace(/\D/g, '');
  if (cleaned.length === 10) {
    return `+91 ${cleaned.slice(0, 5)} ${cleaned.slice(5)}`;
  }
  if (cleaned.length > 10) {
    return `+${cleaned.slice(0, 2)} ${cleaned.slice(2, 7)} ${cleaned.slice(7)}`;
  }
  return cleaned;
}

function createAlertMessage(alert: Alert): string {
  const emoji = {
    motion: '📹',
    unauthorized: '🚨',
    suspicious: '⚠️',
    intrusion: '🔴',
  }[alert.type];
  
  const typeLabel = {
    motion: 'Motion Detected',
    unauthorized: 'Unauthorized Person',
    suspicious: 'Suspicious Activity',
    intrusion: 'Intrusion Alert',
  }[alert.type];
  
  const lines = [
    `${emoji} *Smart Surveillance System ALERT* ${emoji}`,
    '',
    `*Type:* ${typeLabel}`,
    `*Severity:* ${alert.severity.toUpperCase()}`,
    `*Time:* ${new Date(alert.timestamp).toLocaleString()}`,
    '',
    `*Details:* ${alert.message}`,
    '',
    alert.image ? '📸 Image captured and saved to gallery.' : '',
    '',
    '_This is an automated alert from Smart Surveillance System._',
  ];
  
  return lines.filter(Boolean).join('\n');
}

export function sendWhatsAppAlerts(
  mobileNumbers: string[],
  alert: Alert
): WhatsAppAlertResult[] {
  const message = createAlertMessage(alert);
  const encodedMessage = encodeURIComponent(message);
  
  return mobileNumbers.map(num => {
    const waNumber = formatPhoneForWhatsApp(num);
    const formatted = formatDisplayNumber(num);
    const url = `https://wa.me/${waNumber}?text=${encodedMessage}`;
    
    // Try to open WhatsApp - browser may block popup, that's OK
    const popup = window.open(url, `_blank_${num}`, 'width=600,height=800');
    
    return {
      number: num,
      formatted,
      url,
      window: popup,
    };
  });
}

export function createTestAlert(): Alert {
  return {
    id: 'test-' + Date.now(),
    type: 'intrusion',
    severity: 'critical',
    timestamp: new Date(),
    message: '🧪 TEST ALERT: This is a test notification from Smart Surveillance System. If you received this, your WhatsApp alerts are configured correctly!',
    image: '',
  };
}

// Show toast notification in UI
export function showAlertToast(formattedNumber: string, success: boolean): void {
  const toast = document.createElement('div');
  toast.className = `fixed z-50 flex items-center gap-3 rounded-xl px-5 py-3 text-sm font-medium text-white shadow-2xl animate-in slide-in-from-right ${
    success ? 'bg-emerald-600' : 'bg-amber-600'
  }`;
  
  const icon = success 
    ? '<svg class="h-5 w-5" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>'
    : '<svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>';
  
  toast.innerHTML = `${icon} ${success ? '📱 Alert sent to' : '⚠️ Popup blocked for'} ${formattedNumber}`;
  
  // Position toast - stack them
  const existingToasts = document.querySelectorAll('[data-alert-toast]');
  const offset = existingToasts.length * 60 + 24;
  toast.style.bottom = `${offset}px`;
  toast.style.left = '24px';
  toast.setAttribute('data-alert-toast', 'true');
  
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(-100%)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}
