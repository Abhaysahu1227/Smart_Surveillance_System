import * as faceapi from '@vladmandic/face-api';
import * as cocoSsd from '@tensorflow-models/coco-ssd';
import '@tensorflow/tfjs';

// Models served from Vladmandic's CDN (compatible with @vladmandic/face-api)
const FACE_MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model/';

let faceModelsLoaded = false;
let faceModelsLoading: Promise<void> | null = null;
let cocoModel: cocoSsd.ObjectDetection | null = null;
let cocoLoading: Promise<cocoSsd.ObjectDetection> | null = null;

export async function loadFaceModels(): Promise<void> {
  if (faceModelsLoaded) return;
  if (faceModelsLoading) return faceModelsLoading;

  faceModelsLoading = (async () => {
    await Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri(FACE_MODEL_URL),
      faceapi.nets.faceLandmark68Net.loadFromUri(FACE_MODEL_URL),
      faceapi.nets.faceRecognitionNet.loadFromUri(FACE_MODEL_URL),
    ]);
    faceModelsLoaded = true;
  })();

  return faceModelsLoading;
}

export async function loadCocoModel(): Promise<cocoSsd.ObjectDetection> {
  if (cocoModel) return cocoModel;
  if (cocoLoading) return cocoLoading;

  cocoLoading = cocoSsd.load({ base: 'lite_mobilenet_v2' }).then(m => {
    cocoModel = m;
    return m;
  });

  return cocoLoading;
}

export interface DetectedFace {
  box: { x: number; y: number; width: number; height: number };
  descriptor: Float32Array;
  matchedName: string | null;
  distance: number;
}

export interface DetectedObject {
  bbox: [number, number, number, number]; // x, y, width, height
  class: string;
  score: number;
}

const FACE_MATCH_THRESHOLD = 0.55; // lower = stricter

export async function detectFaces(
  video: HTMLVideoElement,
  authorizedDescriptors: { name: string; descriptor: Float32Array }[]
): Promise<DetectedFace[]> {
  if (!faceModelsLoaded) return [];
  if (video.readyState < 2) return [];

  const detections = await faceapi
    .detectAllFaces(video, new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 }))
    .withFaceLandmarks()
    .withFaceDescriptors();

  return detections.map(d => {
    const box = d.detection.box;
    let bestMatch: { name: string; distance: number } | null = null;

    for (const auth of authorizedDescriptors) {
      const distance = faceapi.euclideanDistance(d.descriptor, auth.descriptor);
      if (!bestMatch || distance < bestMatch.distance) {
        bestMatch = { name: auth.name, distance };
      }
    }

    return {
      box: { x: box.x, y: box.y, width: box.width, height: box.height },
      descriptor: d.descriptor,
      matchedName: bestMatch && bestMatch.distance < FACE_MATCH_THRESHOLD ? bestMatch.name : null,
      distance: bestMatch?.distance ?? 999,
    };
  });
}

export async function detectObjects(video: HTMLVideoElement): Promise<DetectedObject[]> {
  if (!cocoModel || video.readyState < 2) return [];
  const predictions = await cocoModel.detect(video, 10, 0.5);
  return predictions.map(p => ({
    bbox: p.bbox as [number, number, number, number],
    class: p.class,
    score: p.score,
  }));
}

// Compute face descriptor from a single image (for adding authorized faces)
export async function computeFaceDescriptor(imageDataUrl: string): Promise<Float32Array | null> {
  if (!faceModelsLoaded) await loadFaceModels();

  const img = await faceapi.fetchImage(imageDataUrl);
  const detection = await faceapi
    .detectSingleFace(img, new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.4 }))
    .withFaceLandmarks()
    .withFaceDescriptor();

  return detection?.descriptor ?? null;
}

// Suspicious objects that should trigger alerts
export const SUSPICIOUS_OBJECTS = new Set([
  'knife', 'scissors', 'baseball bat', 'gun', 'fire hydrant',
]);

export const TRACKED_OBJECTS = new Set([
  'person', 'car', 'truck', 'motorcycle', 'bicycle', 'dog', 'cat',
  'backpack', 'handbag', 'suitcase', 'cell phone', 'laptop',
  ...SUSPICIOUS_OBJECTS,
]);
