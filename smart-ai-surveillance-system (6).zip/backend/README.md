# 🐍 Python OpenCV + NumPy + YOLO Surveillance Backend

This is the real-time AI computer-vision intelligence backend of **Smart Surveillance System**. It uses OpenCV for high-performance frame processing, NumPy for contour-based motion tracking, PyTorch YOLOv8 for weapon and object classification, and `face_recognition` for identifying authorized vs unauthorized individuals.

## 📦 Features & Capabilities
1. **Adaptive Motion Tracking**: Multi-frame absolute-differencing with Gaussian blurring (low latency, minimal CPU overhead).
2. **YOLOv8 Object Recognition**: Classifies weapons (`knife`, `scissors`, etc.) and alerts when high-risk objects are identified.
3. **Face Recognition Encodings**: Evaluates 128-dimensional facial vectors against enrolled faces inside `/authorized_faces`.
4. **WhatsApp Automation**: Uses Twilio Sandbox or customizable webhooks to send high-priority media alerts to registered mobile numbers.
5. **MJPEG Stream Engine**: Compiles and yields an interactive multipart JPEG stream direct to your browser or the dashboard UI.

---

## 🚀 Setup & Execution Guide

### 1. Prerequisites
Make sure you have **Python 3.9+** and C++ compilers installed (required to build the `dlib` library used by `face-recognition`).
- **Mac**: `brew install cmake`
- **Linux**: `sudo apt-get install build-essential cmake`
- **Windows**: Install [Visual Studio Build Tools](https://visualstudio.microsoft.com/visual-cpp-build-tools/) (select C++ desktop workload).

### 2. Installation
Navigate to this backend folder and install dependencies:
```bash
pip install -r requirements.txt
```

### 3. Start the Server
Run the Flask server:
```bash
python app.py
```
The backend will launch at **`http://localhost:5000`** and will automatically download the lightweight `yolov8n.pt` model weights on first start!

---

## 📹 Configuring IP Cameras or CCTV Cards
By default, the system initializes with `camera_index=0` (built-in webcam).
To hook up custom streams (CCTV, DVR cards, RTSP / IP cams), modify `backend/app.py`:

```python
# For an RTSP IP Camera Stream:
system = SmartSurveillance(camera_index="rtsp://admin:password@192.168.1.100:554/h264Preview_01_main")

# For external DVR cards/USB cameras:
system = SmartSurveillance(camera_index=1)
```

---

## 📱 Twilio WhatsApp Integration Setup
To receive automated alerts on your phone, configure your keys inside `backend/whatsapp_alert.py`:
- Sign up for a free account at [Twilio](https://www.twilio.com).
- Copy your `Account SID` and `Auth Token` and paste them into:
  - `TWILIO_ACCOUNT_SID`
  - `TWILIO_AUTH_TOKEN`
- Ensure you join the WhatsApp sandbox by sending the code provided in your Twilio console to the Twilio WhatsApp number.
