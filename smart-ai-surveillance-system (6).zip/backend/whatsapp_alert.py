import os
from twilio.rest import Client

# Configure your Twilio Credentials (can also be loaded via env variables)
TWILIO_ACCOUNT_SID = os.environ.get('TWILIO_ACCOUNT_SID', 'your_account_sid_here')
TWILIO_AUTH_TOKEN = os.environ.get('TWILIO_AUTH_TOKEN', 'your_auth_token_here')
TWILIO_WHATSAPP_NUMBER = os.environ.get('TWILIO_WHATSAPP_NUMBER', 'whatsapp:+14155238886') # Twilio Sandbox Number

def send_whatsapp_alert(to_number: str, alert_message: str, image_url: str = None) -> bool:
    """
    Sends a WhatsApp alert to a registered mobile number using Twilio.
    
    :param to_number: 10-digit mobile number or full international format (e.g. '919876543210')
    :param alert_message: The text body of the alert
    :param image_url: Optional URL to the captured suspicious/unauthorized activity image
    :return: True if sent successfully, False otherwise
    """
    # Clean and format the destination number
    clean_number = ''.join(filter(str.isdigit, to_number))
    if len(clean_number) == 10:
        clean_number = f"91{clean_number}" # Default to Indian country code if 10-digit
        
    formatted_to = f"whatsapp:+{clean_number}"
    
    # Check if credentials are set
    if TWILIO_ACCOUNT_SID == 'your_account_sid_here' or TWILIO_AUTH_TOKEN == 'your_auth_token_here':
        print(f"[SIMULATED WHATSAPP] To: {formatted_to}")
        print(f"Message: {alert_message}")
        if image_url:
            print(f"Attachment URL: {image_url}")
        return True

    try:
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        
        message_kwargs = {
            "body": alert_message,
            "from_": TWILIO_WHATSAPP_NUMBER,
            "to": formatted_to
        }
        
        # Include media if an external URL is provided (Twilio requires a public URL)
        if image_url:
            message_kwargs["media_url"] = [image_url]
            
        message = client.messages.create(**message_kwargs)
        print(f"[WHATSAPP SENT] SID: {message.sid} to {formatted_to}")
        return True
    except Exception as e:
        print(f"[WHATSAPP ERROR] Failed to send to {formatted_to}: {str(e)}")
        return False
