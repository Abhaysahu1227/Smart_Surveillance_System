import cv2
import numpy as np
import os
import time
import json
from threading import Thread, Lock
from datetime import datetime
from ultralytics import YOLO
import face_recognition
from whatsapp_alert import send_whatsapp_alert

class SmartSurveillance:
    def __init__(self, camera_index=0, model_name='yolov8n.pt'):
        self.camera_index = camera_index
        self.lock = Lock()
        self.is_running = False
        
        # Load YOLO model
        print("Loading YOLOv8 model...")
        self.model = YOLO(model_name)
        
        # Paths
        self.gallery_dir = os.path.join(os.path.dirname(__file__), 'gallery')
        self.faces_dir = os.path.join(os.path.dirname(__file__), 'authorized_faces')
        os.makedirs(self.gallery_dir, exist_ok=True)
        os.makedirs(self.faces_dir, exist_ok=True)
        
        # Load authorized faces
        self.authorized_encodings = []
        self.authorized_names = []
        self.load_authorized_faces()
        
        # Motion detection state
        self.prev_frame = None
        self.motion_sensitivity = 1500  # Minimum contour area for motion detection
        
        # Alert settings
        self.mobile_numbers = []
        self.alerts_enabled = True
        self.last_alert_time = {
            'motion': 0,
            'unauthorized': 0,
            'suspicious': 0
        }
        self.alert_cooldown = 10 # seconds
        
        # Active detections lists (for API info)
        self.active_objects = []
        self.active_faces = []
        self.motion_detected = False
        
        # Alert database
        self.alerts_db_path = os.path.join(os.path.dirname(__file__), 'alerts.json')
        self.alerts_history = []
        self.load_alerts()

        # Suspicious object classes (YOLO coco class indexes/names)
        self.suspicious_classes = {'knife', 'scissors', 'baseball bat', 'gun'}

    def load_authorized_faces(self):
        """Loads and encodes all images in authorized_faces directory."""
        self.authorized_encodings = []
        self.authorized_names = []
        print("Loading authorized faces...")
        for filename in os.listdir(self.faces_dir):
            if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                name = os.path.splitext(filename)[0]
                path = os.path.join(self.faces_dir, filename)
                try:
                    img = face_recognition.load_image_file(path)
                    encodings = face_recognition.face_encodings(img)
                    if encodings:
                        self.authorized_encodings.append(encodings[0])
                        self.authorized_names.append(name)
                        print(f"Loaded authorized face: {name}")
                except Exception as e:
                    print(f"Error loading face {filename}: {e}")

    def load_alerts(self):
        if os.path.exists(self.alerts_db_path):
            try:
                with open(self.alerts_db_path, 'r') as f:
                    self.alerts_history = json.load(f)
            except:
                self.alerts_history = []

    def save_alert(self, alert_type, message, image_path):
        alert_item = {
            "id": str(int(time.time() * 1000)),
            "type": alert_type,
            "timestamp": datetime.now().isoformat(),
            "message": message,
            "image": os.path.basename(image_path),
            "severity": "critical" if alert_type in ['unauthorized', 'suspicious'] else "medium"
        }
        self.alerts_history.insert(0, alert_item)
        # Limit history to 200 items
        self.alerts_history = self.alerts_history[:200]
        
        with open(self.alerts_db_path, 'w') as f:
            json.dump(self.alerts_history, f, indent=4)
            
        # Trigger WhatsApp Alerts
        if self.alerts_enabled and self.mobile_numbers:
            wa_message = f"🚨 *SMART SURVEILLANCE SYSTEM ALERT* 🚨\n\n*Type:* {alert_type.upper()}\n*Time:* {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n*Details:* {message}"
            for num in self.mobile_numbers:
                send_whatsapp_alert(num, wa_message)

    def detect_motion(self, frame) -> bool:
        """NumPy and contour-based motion detection."""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (21, 21), 0)
        
        if self.prev_frame is None:
            self.prev_frame = gray
            return False
            
        # Compute absolute difference between current frame and previous frame
        frame_delta = cv2.absdiff(self.prev_frame, gray)
        thresh = cv2.threshold(frame_delta, 25, 255, cv2.THRESH_BINARY)[1]
        
        # Dilate thresholded image to fill in holes
        thresh = cv2.dilate(thresh, None, iterations=2)
        contours, _ = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        motion_found = False
        for contour in contours:
            if cv2.contourArea(contour) < self.motion_sensitivity:
                continue
            motion_found = True
            # Draw motion bounding box (optional, thin dashed line indicator)
            x, y, w, h = cv2.boundingRect(contour)
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 255), 1)
            
        self.prev_frame = gray
        return motion_found

    def process_frame(self, frame):
        """Main pipeline: Motion -> YOLO -> Face Recognition."""
        annotated_frame = frame.copy()
        h, w, _ = frame.shape
        
        # 1. Motion Detection
        self.motion_detected = self.detect_motion(frame)
        
        # If no motion, we skip heavier YOLO / Face recognition to save CPU
        if not self.motion_detected:
            self.active_objects = []
            self.active_faces = []
            return annotated_frame

        # 2. YOLO Object Detection
        results = self.model(frame, verbose=False)
        self.active_objects = []
        person_detected = False
        suspicious_object_detected = False
        sus_objects_list = []

        for r in results:
            boxes = r.boxes
            for box in boxes:
                cls_id = int(box.cls[0])
                cls_name = self.model.names[cls_id]
                conf = float(box.conf[0])
                
                if conf < 0.5:
                    continue
                    
                xyxy = box.xyxy[0].cpu().numpy().astype(int)
                self.active_objects.append({
                    "class": cls_name,
                    "confidence": conf,
                    "box": xyxy.tolist()
                })
                
                if cls_name == 'person':
                    person_detected = True
                
                # Check for suspicious objects (weapons)
                if cls_name in self.suspicious_classes:
                    suspicious_object_detected = True
                    sus_objects_list.append(cls_name)
                    # Draw suspicious orange box
                    cv2.rectangle(annotated_frame, (xyxy[0], xyxy[1]), (xyxy[2], xyxy[3]), (0, 165, 255), 2)
                    cv2.putText(annotated_frame, f"WARNING: {cls_name}", (xyxy[0], xyxy[1] - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 165, 255), 2)
                else:
                    # Draw normal blue box
                    cv2.rectangle(annotated_frame, (xyxy[0], xyxy[1]), (xyxy[2], xyxy[3]), (255, 0, 0), 2)
                    cv2.putText(annotated_frame, f"{cls_name} {conf:.2f}", (xyxy[0], xyxy[1] - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 1)

        # 3. Face Recognition (Only run if a person is in the frame)
        self.active_faces = []
        unauthorized_face_detected = False
        unknown_faces_count = 0

        if person_detected:
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            face_locations = face_recognition.face_locations(rgb_frame)
            face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

            for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
                # Look for a match with authorized faces
                matches = face_recognition.compare_faces(self.authorized_encodings, face_encoding, tolerance=0.55)
                name = "Unknown"

                if True in matches:
                    first_match_index = matches.index(True)
                    name = self.authorized_names[first_match_index]
                    # Draw authorized green box
                    cv2.rectangle(annotated_frame, (left, top), (right, bottom), (0, 255, 0), 2)
                    cv2.putText(annotated_frame, f"Authorized: {name}", (left, top - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                else:
                    unauthorized_face_detected = True
                    unknown_faces_count += 1
                    # Draw unauthorized red box
                    cv2.rectangle(annotated_frame, (left, top), (right, bottom), (0, 0, 255), 2)
                    cv2.putText(annotated_frame, "UNAUTHORIZED PERSON", (left, top - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
                
                self.active_faces.append({
                    "name": name,
                    "box": [left, top, right - left, bottom - top]
                })

        # 4. Handle Alert Triggers & Image Capturing
        now = time.time()
        
        # Trigger Suspicious Object Alert
        if suspicious_object_detected and (now - self.last_alert_time['suspicious'] > self.alert_cooldown):
            self.last_alert_time['suspicious'] = now
            filename = f"suspicious_{int(now)}.jpg"
            filepath = os.path.join(self.gallery_dir, filename)
            cv2.imwrite(filepath, annotated_frame)
            self.save_alert(
                'suspicious',
                f"⚠️ Suspicious weapons/items detected in area: {', '.join(sus_objects_list)}",
                filepath
            )
            
        # Trigger Unauthorized Person Alert
        elif unauthorized_face_detected and (now - self.last_alert_time['unauthorized'] > self.alert_cooldown):
            self.last_alert_time['unauthorized'] = now
            filename = f"unauthorized_{int(now)}.jpg"
            filepath = os.path.join(self.gallery_dir, filename)
            cv2.imwrite(filepath, annotated_frame)
            self.save_alert(
                'unauthorized',
                f"🚨 Unauthorized person detected ({unknown_faces_count} unrecognized face(s) in restricted zone)",
                filepath
            )
            
        # Trigger General Motion Alert
        elif self.motion_detected and (now - self.last_alert_time['motion'] > 15): # higher cooldown for general motion
            self.last_alert_time['motion'] = now
            filename = f"motion_{int(now)}.jpg"
            filepath = os.path.join(self.gallery_dir, filename)
            cv2.imwrite(filepath, annotated_frame)
            self.save_alert(
                'motion',
                "📹 Significant activity and movement detected.",
                filepath
            )

        return annotated_frame

    def start(self):
        with self.lock:
            if self.is_running:
                return
            self.is_running = True
            self.thread = Thread(target=self._capture_loop, daemon=True)
            self.thread.start()

    def stop(self):
        with self.lock:
            self.is_running = False

    def _capture_loop(self):
        cap = cv2.VideoCapture(self.camera_index)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        
        while self.is_running:
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.1)
                continue
                
            # Process & detect
            annotated = self.process_frame(frame)
            
            # Encode frame to JPEG for live streaming
            _, jpeg = cv2.imencode('.jpg', annotated)
            self.current_jpeg = jpeg.tobytes()
            
            # Control frame rate (~20-25 FPS)
            time.sleep(0.04)
            
        cap.release()
        self.prev_frame = None
