import os
import json
import base64
from flask import Flask, render_template, Response, jsonify, request, send_from_directory
from flask_cors import CORS
from surveillance import SmartSurveillance

app = Flask(__name__)
CORS(app) # Allow React frontend to connect easily

# Initialize Smart Surveillance System Core
# Uses default web camera (0). Update index if using external CCTV card / IP Cam stream URL.
system = SmartSurveillance(camera_index=0)

# Settings Path
SETTINGS_PATH = os.path.join(os.path.dirname(__file__), 'settings.json')

def load_settings():
    if os.path.exists(SETTINGS_PATH):
        try:
            with open(SETTINGS_PATH, 'r') as f:
                data = json.load(f)
                system.mobile_numbers = data.get('mobileNumbers', [])
                system.alerts_enabled = data.get('alertsEnabled', True)
                system.motion_sensitivity = data.get('motionSensitivity', 1500)
                return data
        except:
            pass
    return {
        "mobileNumbers": [],
        "alertsEnabled": True,
        "motionSensitivity": 1500
    }

def save_settings(data):
    with open(SETTINGS_PATH, 'w') as f:
        json.dump(data, f, indent=4)
    # Sync settings with system
    system.mobile_numbers = data.get('mobileNumbers', [])
    system.alerts_enabled = data.get('alertsEnabled', True)
    system.motion_sensitivity = data.get('motionSensitivity', 1500)

# Load Settings on Startup
load_settings()

def generate_frames():
    """Generator for processed MJPEG video stream."""
    while True:
        if not system.is_running:
            # Send a default placeholder "Camera Offline" frame
            placeholder_path = os.path.join(os.path.dirname(__file__), 'static', 'offline.jpg')
            if os.path.exists(placeholder_path):
                with open(placeholder_path, 'rb') as f:
                    frame = f.read()
            else:
                frame = b''
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
            import time
            time.sleep(1)
            continue
            
        try:
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + system.current_jpeg + b'\r\n')
        except:
            pass
        import time
        time.sleep(0.04)

@app.route('/video_feed')
def video_feed():
    """Streaming video feed endpoint."""
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/api/status', methods=['GET'])
def get_status():
    return jsonify({
        "isMonitoring": system.is_running,
        "motionDetected": system.motion_detected,
        "activeFaces": system.active_faces,
        "activeObjects": system.active_objects
    })

@app.route('/api/toggle', methods=['POST'])
def toggle_monitoring():
    data = request.json or {}
    start = data.get('start', not system.is_running)
    
    if start:
        system.start()
    else:
        system.stop()
        
    return jsonify({"isMonitoring": system.is_running})

@app.route('/api/alerts', methods=['GET'])
def get_alerts():
    return jsonify(system.alerts_history)

@app.route('/api/alerts/clear', methods=['POST'])
def clear_alerts():
    system.alerts_history = []
    if os.path.exists(system.alerts_db_path):
        os.remove(system.alerts_db_path)
    return jsonify({"success": True})

@app.route('/api/settings', methods=['GET', 'POST'])
def handle_settings():
    if request.method == 'POST':
        data = request.json or {}
        save_settings(data)
        return jsonify({"success": True, "settings": data})
    else:
        return jsonify(load_settings())

@app.route('/api/gallery', methods=['GET'])
def get_gallery():
    files = []
    for f in os.listdir(system.gallery_dir):
        if f.lower().endswith(('.png', '.jpg', '.jpeg')):
            path = os.path.join(system.gallery_dir, f)
            stat = os.stat(path)
            files.append({
                "id": f,
                "image": f"/api/gallery/image/{f}",
                "timestamp": stat.st_mtime,
                "type": "unauthorized" if "unauthorized" in f else "suspicious" if "suspicious" in f else "motion"
            })
    # Sort newest first
    files.sort(key=lambda x: x['timestamp'], reverse=True)
    return jsonify(files)

@app.route('/api/gallery/image/<filename>', methods=['GET'])
def get_gallery_image(filename):
    return send_from_directory(system.gallery_dir, filename)

@app.route('/api/faces', methods=['GET', 'POST'])
def handle_faces():
    if request.method == 'POST':
        # Add a new authorized face
        data = request.json or {}
        name = data.get('name')
        image_data_url = data.get('image') # Base64 data URL
        
        if not name or not image_data_url:
            return jsonify({"error": "Missing name or image"}), 400
            
        try:
            # Decode base64 image
            header, encoded = image_data_url.split(",", 1)
            image_bytes = base64.b64decode(encoded)
            
            # Save file
            filename = f"{name.replace(' ', '_')}.jpg"
            filepath = os.path.join(system.faces_dir, filename)
            with open(filepath, 'wb') as f:
                f.write(image_bytes)
                
            # Reload faces & descriptors inside system
            system.load_authorized_faces()
            return jsonify({"success": True})
        except Exception as e:
            return jsonify({"error": str(e)}), 500
    else:
        # Get authorized faces
        faces = []
        for f in os.listdir(system.faces_dir):
            if f.lower().endswith(('.png', '.jpg', '.jpeg')):
                faces.append({
                    "id": f,
                    "name": os.path.splitext(f)[0].replace('_', ' '),
                    "image": f"/api/faces/image/{f}"
                })
        return jsonify(faces)

@app.route('/api/faces/image/<filename>', methods=['GET'])
def get_face_image(filename):
    return send_from_directory(system.faces_dir, filename)

@app.route('/api/faces/<filename>', methods=['DELETE'])
def delete_face(filename):
    path = os.path.join(system.faces_dir, filename)
    if os.path.exists(path):
        os.remove(path)
        system.load_authorized_faces()
        return jsonify({"success": True})
    return jsonify({"error": "File not found"}), 404

# ─── Authentication ──────────────────────────────────────────
USERS_DB = {
    "admin": {"password": "admin123", "name": "Administrator", "role": "admin"},
    "operator": {"password": "operator123", "name": "Security Operator", "role": "operator"},
    "viewer": {"password": "viewer123", "name": "Viewer", "role": "viewer"},
}

@app.route('/api/auth/login', methods=['POST'])
def api_login():
    data = request.json or {}
    username = data.get('username', '').strip().lower()
    password = data.get('password', '').strip()
    
    user = USERS_DB.get(username)
    if not user or user['password'] != password:
        return jsonify({"error": "Invalid username or password"}), 401
    
    return jsonify({
        "success": True,
        "user": {
            "id": f"usr_{username}",
            "username": username,
            "name": user['name'],
            "role": user['role'],
        }
    })

@app.route('/api/auth/verify', methods=['GET'])
def api_verify():
    # In production, check JWT/session token from headers
    return jsonify({"authenticated": True})

if __name__ == '__main__':
    # Create static assets directory
    os.makedirs(os.path.join(os.path.dirname(__file__), 'static'), exist_ok=True)
    
    # Run server on port 5000 (accessible locally by frontend)
    app.run(host='0.0.0.0', port=5000, debug=False)
